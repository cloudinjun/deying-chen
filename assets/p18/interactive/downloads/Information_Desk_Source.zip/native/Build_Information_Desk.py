# -*- coding: utf-8 -*-
"""Run in Rhino 8 ScriptEditor (Python 3) to rebuild Information_Desk.gh.

This script creates and wires native Grasshopper components for a neutral Information Desk study.
The saved definition contains no GhPython, C# or other script components.
Units: millimetres. X = width; Y = depth; front = Y 0; floor = Z 0.
"""
import os
import System
import Rhino
import clr
clr.AddReference("Grasshopper")
clr.AddReference("GH_IO")
import Grasshopper as GH
import GH_IO
from System.Drawing import PointF, Point, RectangleF, Color
from Grasshopper.Kernel import (
    GH_Document, GH_Component, IGH_VariableParameterComponent,
    GH_ParameterSide, GH_ParamAccess
)
from Grasshopper.Kernel.Special import (
    GH_NumberSlider, GH_MultiDimensionalSlider, GH_Panel,
    GH_ValueList, GH_ValueListItem, GH_Group
)
from Grasshopper.Kernel.Parameters import Param_Number, Param_Geometry, Param_Colour
from Grasshopper.Kernel.Types import GH_Number, GH_Mesh, GH_Colour
from Rhino.Geometry import Point3d

# Verified native Grasshopper component IDs.
IDS = {
    "expression": "9df5e896-552d-4c8c-b9ca-4fc147ffa022",
    "domain": "d1a28e95-cf96-4936-bf34-8bf142d731bf",
    "box": "79aa7f47-397c-4d3f-9761-aaf421bb7f5f",
    "dispatch": "d8332545-21b2-4716-96e3-8559a9876e17",
    "point": "3581f42a-9592-4549-bd6b-1c0fc39d067b",
    "depoint": "670fcdba-da07-4eb4-b1c1-bfa0729d767d",
    "series": "e64c5fb1-845c-4ab1-8911-5f338516ba67",
    "move": "e9eb1dcf-92f6-4d4d-84ae-96222d60f56b",
    "preview": "537b0419-bbc2-4ff4-bf08-afe526367b2c",
    "merge": "3cadddef-1e2b-4c09-9390-0e8f78f7609f",
    "filter": "eeafc956-268e-461d-8e73-ee05c6f72c01",
    "item": "59daf374-bc21-4a5e-8282-5504fb7ae9ae",
    "plane": "bc3e379e-7206-4e7b-b63a-ff61f4b38a3e",
    "text": "5a41528b-12b9-40dc-a3f2-842034d267c4",
}

ROOT = os.path.dirname(os.path.abspath(__file__))
OUTPUT = os.path.join(ROOT, "Information_Desk.gh")
rhino_gh = Rhino.RhinoApp.GetPlugInObject("Grasshopper")
rhino_gh.RunHeadless()
doc = GH_Document()
doc.Enabled = False
doc.FilePath = OUTPUT
objects = {}
groups = {}
group_origin = {}
group_cursor = {}
current_group = ""
constants = {}


def begin_group(name, x, y):
    global current_group
    current_group = name
    groups[name] = []
    group_origin[name] = (x, y)
    group_cursor[name] = 0


def add(obj, name=None):
    """Place a native object in the current group."""
    obj.CreateAttributes()
    count = group_cursor[current_group]
    x, y = group_origin[current_group]
    obj.Attributes.Pivot = PointF(x + (count % 7) * 160, y + (count // 7) * 145)
    group_cursor[current_group] += 1
    if name:
        obj.NickName = name
        objects[name] = obj
    if isinstance(obj, GH_Component):
        obj.Hidden = True
    doc.AddObject(obj, False)
    groups[current_group].append(obj.InstanceGuid)
    return obj


def component(kind, name=None):
    proxy = GH.Instances.ComponentServer.EmitObjectProxy(System.Guid(IDS[kind]))
    obj = System.Activator.CreateInstance(proxy.CreateInstance().GetType())
    return add(obj, name)


def constant(value):
    if value in constants:
        return constants[value]
    obj = Param_Number()
    obj.PersistentData.Append(GH_Number(float(value)))
    add(obj)
    constants[value] = obj
    return obj


def output(source):
    if isinstance(source, tuple):
        return source[0].Params.Output[source[1]]
    if isinstance(source, (int, float)):
        return constant(source)
    if isinstance(source, GH_Component):
        return source.Params.Output[0]
    return source


def wire(source, target, index):
    target.Params.Input[index].AddSource(output(source))


def expression(formula, inputs, name=None):
    obj = component("expression", name)
    variable = IGH_VariableParameterComponent(obj)
    while obj.Params.Input.Count < len(inputs):
        index = obj.Params.Input.Count
        obj.Params.RegisterInputParam(variable.CreateParameter(GH_ParameterSide.Input, index))
    while obj.Params.Input.Count > len(inputs):
        obj.Params.UnregisterInputParameter(obj.Params.Input[obj.Params.Input.Count - 1], True)
    for index, item in enumerate(inputs):
        letter, source = item
        obj.Params.Input[index].Name = letter
        obj.Params.Input[index].NickName = letter
        wire(source, obj, index)
    obj.Expression = formula
    obj.Params.OnParametersChanged()
    return obj


def slider(name, low, high, value, integer=False):
    obj = GH_NumberSlider()
    add(obj, name)
    obj.Slider.Minimum = System.Decimal(low)
    obj.Slider.Maximum = System.Decimal(high)
    obj.Slider.DecimalPlaces = 0 if integer else 1
    if integer:
        obj.Slider.Type = GH.GUI.Base.GH_SliderAccuracy.Integer
    obj.SetSliderValue(System.Decimal(value))
    return obj


def panel(name, text):
    obj = GH_Panel()
    obj.UserText = text
    return add(obj, name)


def domain(start, end, name=None):
    obj = component("domain", name)
    wire(start, obj, 0)
    wire(end, obj, 1)
    return obj


def gate(geometry, enabled):
    obj = component("dispatch")
    wire(geometry, obj, 0)
    wire(enabled, obj, 1)
    return obj


def box(dx, dy, dz, enabled, name=None):
    obj = component("box", name)
    wire(dx, obj, 1)
    wire(dy, obj, 2)
    wire(dz, obj, 3)
    return gate(obj, enabled)


def point(x, y, z, name=None):
    obj = component("point", name)
    wire(x, obj, 0)
    wire(y, obj, 1)
    wire(z, obj, 2)
    return obj


def offset(source, amount):
    return expression("a+b", [("a", source), ("b", amount)])


def merge(sources, name):
    obj = component("merge", name)
    # Multiple sources on one tree input preserve their data.
    for source in sources:
        wire(source, obj, 0)
    return obj


def mask_sum(sources, name=None):
    if not sources:
        return constant(0)
    inputs = []
    letters = []
    for i, source in enumerate(sources):
        letter = chr(97 + i)
        inputs.append((letter, source))
        letters.append(letter)
    return expression("if(" + "+".join(letters) + ">0,1,0)", inputs, name)


def preview(source, rgb):
    material = Param_Colour()
    material.PersistentData.Append(GH_Colour(Color.FromArgb(*rgb)))
    add(material)
    obj = component("preview")
    obj.Hidden = False
    wire(source, obj, 0)
    wire(material, obj, 1)


# 01. Main controls, measured from finished floor.
begin_group("01 Overall size - mm", -2200, -700)
W = slider("Width", 2000, 4000, 3048)
D = slider("Depth", 1450, 2600, 1828.8)
H = slider("Overall height", 2200, 3200, 2800)
NX = slider("Columns", 2, 3, 3, True)
NY = slider("Rows", 2, 3, 3, True)
CH = slider("Counter height", 760, 1100, 915)
T = slider("Frame section", 30, 60, 40)
SD = slider("Shelf depth", 150, 450, 300)
panel("Read first", "Information Desk / NATIVE CONFIGURATOR\nX = left to right; Y = front to back\nAll dimensions in mm; heights from floor\n0 empty | 1 cabinet | 2 low display | 3 tall shelf\nShared frame is a separate kit of parts.\nSteel shown as section envelopes; joints pending.")

# 02. Two genuine native MD Sliders. Normalized X/Y control both cut directions.
begin_group("02 Move the MD handles to split the grid", -2200, 0)
cut_a = GH_MultiDimensionalSlider()
add(cut_a, "Cut A")
cut_a.Value = Point3d(1.0 / 3.0, 0.33, 0)
cut_b = GH_MultiDimensionalSlider()
add(cut_b, "Cut B")
cut_b.Value = Point3d(2.0 / 3.0, 0.77, 0)
de_a = component("depoint")
de_b = component("depoint")
wire(cut_a, de_a, 0)
wire(cut_b, de_b, 0)
ratios = []
for name in ["Width split", "Depth split"]:
    choose = GH_ValueList()
    add(choose, name)
    choose.ListItems.Clear()
    for text, value in [("Free MD", "0"), ("1 : 1", "1"), ("1 : 2", "2"), ("2 : 1", "3")]:
        choose.ListItems.Add(GH_ValueListItem(text, value))
    choose.SelectItem(0)
    ratios.append(choose)
panel("Cuts", "Stream Filter selects the active MD data:\n2 cells = A; 3 cells = A + B.\nWidth and depth switch independently.\n2 cells: Free MD / 1:1 / 1:2 / 2:1\nRatios locate cuts across the full footprint.\nMinimum bay: X 450 / Y 420 mm.\nCrossed handles are sorted; tight bays clamped.")

# 03. Stable cell addresses: M11..M33. Disabled column/row controls remain saved.
types = {}
counts = {}
tops = {}
bottoms = {}
for j in range(3):
    for i in range(3):
        cell = (i, j)
        label = "M" + str(i + 1) + str(j + 1)
        begin_group("03 " + label + " controls", -2200 + i * 1250, 650 + j * 520)
        choose = GH_ValueList()
        add(choose, label + " type")
        choose.ListItems.Clear()
        for text, value in [("0 Empty", "0"), ("1 Cabinet", "1"), ("2 Display", "2"), ("3 Tall shelf", "3")]:
            choose.ListItems.Add(GH_ValueListItem(text, value))
        kind = 0
        if j == 0:
            kind = 1 if i == 2 else 2
        if j == 2:
            kind = 3
        choose.SelectItem(kind)
        types[cell] = choose
        number = 3 if j == 2 else (1 if kind == 2 else 0)
        counts[cell] = slider(label + " shelf count", 0, 6, number, True)
        low = 1180 if j == 2 else 350
        high = 2200 if j == 2 else 650
        bottoms[cell] = slider(label + " first shelf", 250, 2450, low)
        tops[cell] = slider(label + " last shelf", 250, 2550, high)

# 04. Native expressions build a safe, monotonic grid.
begin_group("04 Grid dimensions - native expressions", 1900, -700)
half = expression("t/2", [("t", T)])
negative_half = expression("-t/2", [("t", T)])
axes = []
for axis_name, length, count, first, second, minimum, ratio in [
    ("Width", W, NX, (de_a, 0), (de_b, 0), 450, ratios[0]),
    ("Depth", D, NY, (de_a, 1), (de_b, 1), 420, ratios[1]),
]:
    # Filter stream 0 has one MD cut; stream 1 has two MD cuts.
    two_cuts = merge([first, second], axis_name + " A + B")
    selector = expression("n-2", [("n", count)])
    md_filter = component("filter", axis_name + " MD filter")
    wire(selector, md_filter, 0)
    wire(first, md_filter, 1)
    wire(two_cuts, md_filter, 2)
    selected_cuts = []
    for index in range(2):
        item = component("item")
        wire(md_filter, item, 0)
        wire(index, item, 1)
        # In two-way mode the second item wraps to A and is unused below.
        wire(1, item, 2)
        selected_cuts.append(item)
    first, second = selected_cuts
    first = expression(
        "if(n<2.5,if(p<0.5,a,if(p<1.5,0.5,if(p<2.5,1/3,2/3))),a)",
        [("n", count), ("p", ratio), ("a", first)]
    )
    a = expression(
        "if(n<2.5,max(m+t/2,min(w-t/2-m,a*w)),max(m+t/2,min(w-t/2-2*m,min(a,b)*w)))",
        [("n", count), ("w", length), ("m", minimum), ("a", first), ("b", second), ("t", T)]
    )
    b = expression(
        "if(n<2.5,w-t/2,max(a+m,min(w-t/2-m,max(u,v)*w)))",
        [("n", count), ("w", length), ("t", T), ("a", a), ("m", minimum), ("u", first), ("v", second)]
    )
    end = expression("if(n<2.5,w+m,w-t/2)", [("n", count), ("w", length), ("m", minimum), ("t", T)])
    axes.append([half, a, b, end])
xs, ys = axes
active = {}
for j in range(3):
    for i in range(3):
        active[i, j] = expression(
            "if(nx>i,if(ny>j,if(k>0,1,0),0),0)",
            [("nx", NX), ("ny", NY), ("i", i), ("j", j), ("k", types[i, j])],
            "M%d%d active" % (i + 1, j + 1)
        )

# The original CAD is positioned without resizing. Height is measured in the STEP.
CASTER_HEIGHT = 146.267235552223
BASE = CASTER_HEIGHT + 6
base_z = domain(BASE, offset(T, BASE))
counter_z = domain(expression("h-t", [("h", CH), ("t", T)]), CH)
top_z = domain(expression("h-t", [("h", H), ("t", T)]), H)
lower_post_z = domain(BASE, CH)
upper_post_z = domain(CH, H)
wood_top_z = domain(offset(CH, -25), CH)
floor_z = domain(offset(T, BASE), offset(T, BASE + 18))
steel = []
mounts = []
counters = []
cabinet = []
shelves = []
backing = []
banners = []
caster_points = []
module_sizes = []
node_masks = {}

def neighbours(i, j):
    cells = []
    for x, y in [(i - 1, j - 1), (i, j - 1), (i - 1, j), (i, j)]:
        if (x, y) in active:
            cells.append(active[x, y])
    return cells


begin_group("05 One frame member per grid edge", 1900, 1100)
px = []
py = []
for value in xs:
    px.append(domain(offset(value, negative_half), offset(value, half)))
for value in ys:
    py.append(domain(offset(value, negative_half), offset(value, half)))
rx = []
ry = []
for i in range(3):
    rx.append(domain(offset(xs[i], half), offset(xs[i + 1], negative_half)))
    ry.append(domain(offset(ys[i], half), offset(ys[i + 1], negative_half)))

# Each node is generated once. Beams end at column faces, not at centrelines.
for j in range(4):
    for i in range(4):
        enabled = mask_sum(neighbours(i, j), "Node %d%d" % (i, j))
        node_masks[i, j] = enabled
        steel.append(box(px[i], py[j], lower_post_z, enabled))
        steel.append(box(px[i], py[j], upper_post_z, enabled))
for j in range(4):
    for i in range(3):
        adjacent = []
        for cell in [(i, j - 1), (i, j)]:
            if cell in active:
                adjacent.append(active[cell])
        enabled = mask_sum(adjacent)
        for dz in [base_z, counter_z, top_z]:
            steel.append(box(rx[i], py[j], dz, enabled))
for i in range(4):
    for j in range(3):
        adjacent = []
        for cell in [(i - 1, j), (i, j)]:
            if cell in active:
                adjacent.append(active[cell])
        enabled = mask_sum(adjacent)
        for dz in [base_z, counter_z, top_z]:
            steel.append(box(px[i], ry[j], dz, enabled))

# 06. Caster centres shift into occupied cells at exposed edges.
# Native adapter plates connect the offset mount to the base frame.
begin_group("06 Casters and mounting blanks", 3200, -700)
for j in range(4):
    for i in range(4):
        side_masks = []
        for cells in [
            [(i - 1, j - 1), (i - 1, j)],
            [(i, j - 1), (i, j)],
            [(i - 1, j - 1), (i, j - 1)],
            [(i - 1, j), (i, j)],
        ]:
            side_masks.append(mask_sum([active[c] for c in cells if c in active]))
        left, right, front, rear = side_masks
        cx = expression("x+100*(r-l)", [("x", xs[i]), ("r", right), ("l", left)])
        cy = expression("y+100*(r-l)", [("y", ys[j]), ("r", rear), ("l", front)])
        caster_points.append(gate(point(cx, cy, 0), node_masks[i, j]))
        mx = domain(
            expression("min(x-t/2,c-45)", [("x", xs[i]), ("c", cx), ("t", T)]),
            expression("max(x+t/2,c+45)", [("x", xs[i]), ("c", cx), ("t", T)])
        )
        my = domain(
            expression("min(y-t/2,c-40)", [("y", ys[j]), ("c", cy), ("t", T)]),
            expression("max(y+t/2,c+40)", [("y", ys[j]), ("c", cy), ("t", T)])
        )
        mounts.append(box(mx, my, domain(CASTER_HEIGHT, BASE), node_masks[i, j]))

# 07. Separate removable panels, cabinets and shelves for each cell.
for j in range(3):
    for i in range(3):
        cell = (i, j)
        name = "M%d%d" % (i + 1, j + 1)
        begin_group("07 " + name + " panels and shelves", 4700 + i * 1250, -700 + j * 1500)
        enabled = active[cell]
        kind = types[cell]
        x0 = expression("x+t/2+3", [("x", xs[i]), ("t", T)])
        x1 = expression("x-t/2-3", [("x", xs[i + 1]), ("t", T)])
        y0 = expression("y+t/2+3", [("y", ys[j]), ("t", T)])
        y1 = expression("y-t/2-3", [("y", ys[j + 1]), ("t", T)])
        dx = domain(x0, x1)
        dy = domain(y0, y1)
        counters.append(box(dx, dy, wood_top_z, enabled))
        cabinet.append(box(dx, dy, floor_z, enabled))
        body_z = domain(offset(T, BASE + 18), offset(CH, -28))
        cabinet.append(box(domain(x0, offset(x0, 18)), dy, body_z, enabled))
        cabinet.append(box(domain(offset(x1, -18), x1), dy, body_z, enabled))
        inside_x = domain(offset(x0, 18), offset(x1, -18))
        # Low display has an open public face. Cabinet and tall shelf have a front.
        closed = expression("a*if(k<1.5,1,if(k>2.5,1,0))", [("a", enabled), ("k", kind)])
        cabinet.append(box(inside_x, domain(y0, offset(y0, 18)), body_z, closed))
        # Rear access doors with a central 3 mm gap; locks/hinges are detailing scope.
        middle = expression("(a+b)/2", [("a", x0), ("b", x1)])
        cabinet.append(box(domain(offset(x0, 18), offset(middle, -1.5)), domain(offset(y1, -18), y1), body_z, enabled))
        cabinet.append(box(domain(offset(middle, 1.5), offset(x1, -18)), domain(offset(y1, -18), y1), body_z, enabled))
        tall = expression("a*if(k>2.5,1,0)", [("a", enabled), ("k", kind)])
        shelf_on = expression("a*if(k>1.5,if(n>0,1,0),0)", [("a", enabled), ("k", kind), ("n", counts[cell])])
        # Clamp both chosen heights to the module's usable range.
        lower_limit = expression("if(k>2.5,c+100,b+t+60)", [("k", kind), ("c", CH), ("b", BASE), ("t", T)])
        upper_limit = expression("if(k>2.5,h-400,c-50)", [("k", kind), ("h", H), ("c", CH)])
        first = expression(
            "max(lo,min(hi-40*max(n-1,0),min(a,b)))",
            [("lo", lower_limit), ("hi", upper_limit), ("n", counts[cell]), ("a", bottoms[cell]), ("b", tops[cell])]
        )
        last = expression(
            "max(lo+40*max(n-1,0),min(hi,max(a,b)))",
            [("lo", first), ("hi", upper_limit), ("n", counts[cell]), ("a", bottoms[cell]), ("b", tops[cell])]
        )
        series = component("series")
        wire(0, series, 0)
        wire(1, series, 1)
        wire(expression("max(1,n)", [("n", counts[cell])]), series, 2)
        level = expression("if(n<1.5,a,a+(b-a)*i/max(1,n-1))",
                           [("n", counts[cell]), ("a", first), ("b", last), ("i", series)], name + " shelf levels")
        depth_start = expression("max(a+21,b-d-21)", [("a", y0), ("b", y1), ("d", SD)])
        shelf_x = domain(offset(x0, 18), offset(x1, -18))
        shelf_y = domain(depth_start, offset(y1, -21))
        shelves.append(box(shelf_x, shelf_y, domain(offset(level, -18), level), shelf_on))
        backing.append(box(dx, domain(offset(y1, -12), y1),
                           domain(offset(CH, 3), offset(last, 80)), tall))
        size_x = expression("b-a", [("a", xs[i]), ("b", xs[i + 1])])
        size_y = expression("b-a", [("a", ys[j]), ("b", ys[j + 1])])
        module_sizes.append(gate(point(size_x, size_y, CH), enabled))

# Front signs stay inside the footprint. Text Tag 3D is a native bakeable component.
begin_group("08 Front signs - editable text", 8500, -2200)
texts = ["INFORMATION", "DESK", ""]
for i in range(3):
    enabled = active[i, 0]
    sign_y = domain(offset(T, 3), offset(T, 15))
    sign_z = domain(offset(H, -330), expression("h-t-3", [("h", H), ("t", T)]))
    banners.append(box(rx[i], sign_y, sign_z, enabled))
    origin = point(
        expression("(a+b)/2", [("a", xs[i]), ("b", xs[i + 1])]),
        offset(T, 2), offset(H, -185)
    )
    plane = component("plane")
    wire(origin, plane, 0)
    wire(point(1, 0, 0), plane, 1)
    wire(point(0, 0, 1), plane, 2)
    if texts[i]:
        tag = component("text", "Sign %d - bake text here" % (i + 1))
        tag.Hidden = False
        wire(gate(plane, enabled), tag, 0)
        wire(panel("Sign %d text" % (i + 1), texts[i]), tag, 1)
        size = expression("min(90,(b-a-80)/n)",
                          [("a", xs[i]), ("b", xs[i + 1]), ("n", len(texts[i]) * 0.7)])
        wire(size, tag, 2)
        ink = Param_Colour()
        ink.PersistentData.Append(GH_Colour(Color.FromArgb(245, 190, 35) if i == 2 else Color.White))
        add(ink)
        wire(ink, tag, 3)
        wire(4, tag, 4)

# 08. Native Geometry parameter contains meshes derived from the downloaded STEP.
begin_group("08 Vendor caster geometry - no substitute wheels", 8500, -700)
caster_file = Rhino.FileIO.File3dm.Read(os.path.join(ROOT, "assets", "caster-normalized.3dm"))
caster_geometry = Param_Geometry()
add(caster_geometry, "Manner 301799 CAD")
caster_geometry.Hidden = True
for item in caster_file.Objects:
    if isinstance(item.Geometry, Rhino.Geometry.Mesh):
        caster_geometry.PersistentData.Append(GH_Mesh(item.Geometry.DuplicateMesh()))
caster_vectors = merge(caster_points, "Caster positions")
move = component("move", "Place vendor casters")
wire(caster_geometry, move, 0)
wire(caster_vectors, move, 1)

# 09. Clear category outputs. Bake only these, not the intermediate components.
begin_group("09 Outputs - right-click to bake", 8500, 300)
results = {}
for name, sources, rgb in [
    ("FRAME", steel, (40, 42, 43)),
    ("MOUNTS", mounts, (110, 115, 120)),
    ("COUNTERS", counters, (179, 131, 78)),
    ("CABINETS", cabinet, (151, 111, 70)),
    ("SHELVES", shelves, (200, 155, 97)),
    ("BACK PANELS", backing, (221, 213, 194)),
    ("SIGNS", banners, (35, 37, 38)),
    ("CASTERS", [move], (105, 110, 115)),
]:
    gathered = merge(sources, name + " merge")
    result = Param_Geometry()
    add(result, name)
    result.Hidden = True
    result.AddSource(output(gathered))
    results[name] = result
    preview(result, rgb)
size_output = merge(module_sizes, "MODULE SIZES XYZ = width depth counter height")
panel("Fabrication scope", "Shared columns and rails are generated once.\nBeams stop at column faces; empty cells stay open.\nCaster CAD height = 146.27 mm; catalog = 148 mm.\nMounts are 6 mm adapter blanks; drilling pending.\nConfirm load, stability, locks, joints and elevator clearances before fabrication.")

# Keep the control area compact. Calculations are grouped to its right.
calculation_y = 0
for name in groups:
    ids = groups[name]
    if name.startswith("01"):
        for index, guid in enumerate(ids):
            obj = doc.FindObject(guid, False)
            obj.Attributes.Pivot = PointF(100 + (index % 4) * 330, 100 + (index // 4) * 90)
            if isinstance(obj, GH_Panel):
                obj.Attributes.Pivot = PointF(100, 330)
                obj.Attributes.Bounds = RectangleF(100, 330, 650, 150)
    elif name.startswith("02"):
        for index, guid in enumerate(ids):
            obj = doc.FindObject(guid, False)
            positions = [(100, 630), (500, 630), (850, 630), (1010, 630),
                         (180, 850), (680, 850), (1200, 600)]
            x, y = positions[index]
            obj.Attributes.Pivot = PointF(x, y)
            if isinstance(obj, GH_Panel):
                obj.Attributes.Bounds = RectangleF(1200, 600, 330, 190)
    elif name.startswith("03"):
        label = name.split()[1]
        i = int(label[1]) - 1
        j = int(label[2]) - 1
        for index, guid in enumerate(ids):
            obj = doc.FindObject(guid, False)
            obj.Attributes.Pivot = PointF(180 + i * 500, 1000 + j * 380 + index * 65)
    elif name.startswith("09"):
        for index, guid in enumerate(ids):
            obj = doc.FindObject(guid, False)
            obj.Attributes.Pivot = PointF(100 + (index % 5) * 300, 2350 + (index // 5) * 155)
    else:
        for index, guid in enumerate(ids):
            obj = doc.FindObject(guid, False)
            obj.Attributes.Pivot = PointF(2200 + (index % 7) * 260, calculation_y + (index // 7) * 160)
        calculation_y += ((len(ids) + 6) // 7) * 160 + 220

# Group and save the live definition.
for name in groups:
    group = GH_Group()
    group.NickName = name
    group.Colour = Color.FromArgb(42, 90, 110, 120)
    for guid in groups[name]:
        group.AddObject(guid)
    doc.AddObject(group, False)
doc.Enabled = True
GH_Document.EnableSolutions = True
GH.Instances.DocumentServer.AddDocument(doc)
doc.NewSolution(False)
doc.Properties.ViewTarget = Point(50, 30)
doc.Properties.ZoomFactor = System.Single(0.45)
doc.Properties.Description = "Information Desk modular desk. Native Grasshopper components only. Units: mm."
archive = GH_IO.Serialization.GH_Archive()
archive.AppendObject(doc, "Definition")
if not archive.WriteToFile(OUTPUT, True, False):
    raise RuntimeError("Could not save the Grasshopper file.")
print("Saved: " + OUTPUT)
print("Native objects: " + str(doc.Objects.Count))
