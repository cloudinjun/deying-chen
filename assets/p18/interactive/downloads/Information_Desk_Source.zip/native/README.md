# Information Desk — Native Source Package

This folder contains a neutral, portfolio-ready Grasshopper study for a movable modular Information Desk. The saved definition uses built-in Grasshopper and Rhino components; the Python file is a one-time builder for regenerating the definition, not a runtime dependency.

`Information_Desk.gh` is the earlier shared-frame v1 study. Its native parity reference applies to browser v1 only; browser v2 is a separate browser geometry study.

- `Information_Desk.gh` — native Grasshopper definition with adjustable width, depth, height, counter height, 2–3 columns, 2–3 rows, MD cut handles, ratio presets, module recipes, shelf count, and shelf elevations.
- `Information_Desk_Default.3dm` — layered default 3×3 output with baked `INFORMATION` and `DESK` Text Tag 3D labels.
- `Build_Information_Desk.py` — readable Rhino 8 ScriptEditor builder. It expects the local `assets/` folder when rebuilding.
- `assets/Manner_301799_original.step` — original manufacturer STEP asset, preserved without scaling.
- `assets/caster-normalized.3dm` — lightweight normalized preview mesh used by the native definition.
- `assets/Manner_301799_photo.jpg` — supplier reference image.
- `caster_source.json` — supplier and manufacturer provenance for the caster asset.

The native frame is modeled as section envelopes and the mount plates as blanks. Browser v2 gives each occupied cell its own four-post frame, 12 rails and four supplier-mesh casters, with a 6 mm neighboring seam; separation translates each complete cell, its contents and sign without scaling. Connections, wall thickness, locks, loading, stability, and transport clearance remain fabrication-development items.

## Asset provenance

Caster model: Manner Tango GKL-J-S-100 PTE/K 80, manufacturer reference 301799. Supplier source: CasterHQ. The original model is retained in `assets/Manner_301799_original.step`; the normalized preview is translated to the mounting axis and floor plane, with no scale change.
