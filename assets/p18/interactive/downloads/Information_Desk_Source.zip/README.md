# Information Desk

browser/ contains the current independent-module configurator, including 3D dimensions and source.

native/ contains the earlier shared-frame Grasshopper study and its one-time builder. It has not been revised to match browser v2. Native parity checks apply to v1 only.

The caster mesh is supplier-derived; attribution is retained. This is a digital design study, not tested fabrication documentation.
