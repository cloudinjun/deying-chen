# Verification scope

Current browser v2: `test-mobile-modules.mjs`, `mobile-modules-checks.json` and `browser-v2-checks.json`.

The earlier native-reference, browser-native-comparison, browser-checks and separation-checks files describe browser v1 and the shared-frame Grasshopper study. They do not establish parity for browser v2.
